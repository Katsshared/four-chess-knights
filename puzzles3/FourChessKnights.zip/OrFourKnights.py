'''
Created on 27.06.2026

@author: cat

https://github.com/prateekralhan/Multilingual-Translator/blob/main/app.py

https://lokalise.com/blog/translating-apps-with-gettext-comprehensive-tutorial/

# create .mo
msgfmt -o locales/en/LC_MESSAGES/messages.mo locales/en/LC_MESSAGES/messages.po
msgfmt -o locales/de/LC_MESSAGES/messages.mo locales/de/LC_MESSAGES/messages.po
msgfmt -o locales/ru/LC_MESSAGES/messages.mo locales/ru/LC_MESSAGES/messages.po
msgfmt -o locales/ua/LC_MESSAGES/messages.mo locales/ua/LC_MESSAGES/messages.po
# update .po ASCII - UTF-8
msgmerge -U locales/en/LC_MESSAGES/messages.po locales/messages.pot
msgmerge -U locales/de/LC_MESSAGES/messages.po locales/messages.pot
msgmerge -U locales/ru/LC_MESSAGES/messages.po locales/messages.pot
msgmerge -U locales/ua/LC_MESSAGES/messages.po locales/messages.pot
#create .po
msginit -l en_EN.UTF8 -o locales/en/LC_MESSAGES/messages.po -i locales/messages.pot --no-translator
msginit -l de_DE.UTF8 -o locales/de/LC_MESSAGES/messages.po -i locales/messages.pot --no-translator
msginit -l ru_RU.UTF8 -o locales/ru/LC_MESSAGES/messages.po -i locales/messages.pot --no-translator
msginit -l ua_UA.UTF8 -o locales/ua/LC_MESSAGES/messages.po -i locales/messages.pot --no-translator

#generate .pot
xgettext -d messages -o locales/messages.pot OrFourKnights.py OrSelectLanguage.py OrHelloWorld.py OrChessPuzzles.py --from-code UTF-8


https://phrase.com/blog/posts/translate-python-gnu-gettext/
https://phrase.com/blog/posts/using-google-translate-in-python-applications/

#setup gettext
https://gnuwin32.sourceforge.net/packages/gettext.htm
sudo apt install gettext

cd /home/cat/eclipse-workspace/Orientaion/CHESSPAGE/
streamlit run /home/cat/eclipse-workspace/Orientaion/CHESSPAGE/OrFourKnights.py

'''

import streamlit as st
from streamlit_image_coordinates import streamlit_image_coordinates
import gettext
from PIL import Image, ImageDraw

#st.logo("images/FourKnights.png")

langs = ['en ' + "🇬🇧", 'de ' + "🇩🇪", 'ru ' + "🇷🇺", 'ua ' + "🇺🇦",]

lang_sel = st.sidebar.selectbox(" ", langs)

st.session_state.sellang = lang_sel[0:2]
    
localizator = gettext.translation('messages', localedir='locales', languages=[lang_sel[0:2]])    
localizator.install() 
_ = localizator.gettext 


def add_logo(logo_path, width, height):
    """Read and return a resized logo"""
    logo = Image.open(logo_path)
    modified_logo = logo.resize((width, height))
    return modified_logo

@st.dialog(" ", dismissible=True, on_dismiss="rerun")
def on_click():
    st.header("🇬🇧" + " Four Chess Knights Club") 
    st.header("🇩🇪" + " Vier-Schach-Ritter-Club")
    st.header("🇷🇺" + " Клуб четырех шахматных рыцарей")
    st.header("🇺🇦" + " Клуб чотирьох шахових лицарів")
with st.sidebar:
    img = add_logo(logo_path="images/FourKnights.png", width=100, height=100)
    streamlit_image_coordinates(img, key="global", on_click=on_click)    
                
pg = st.navigation([
    st.Page("OrSelectLanguage.py", title=_("Four Chess Knights"), icon="🏠"),
    st.Page("OrChessStrategy.py", title=_("Strategy"), icon="♟️"),
    st.Page("OrChessTactic.py", title=_("Tactic"), icon="♟️"),
    st.Page("OrChessDebut.py", title=_("Debut"), icon="♟️"),
    st.Page("OrSvgChessStockfish.py", title=_("Play") + " " + _("chess"), icon="♟️"),
    st.Page("OrChessPuzzles.py", title=_("Chess puzzles"), icon="♟️"),
    st.Page("OrSvgEditChessBoard.py", title=_("Chess editor"), icon="♟️"),
    st.Page("OrEmailContact.py", title=_("Contact"), icon="📫"),
#    st.Page(
#        "https://docs.streamlit.io",
#        title=_("This is a translatable string"),
#        icon=":material/open_in_new:"
#    ),
])

pg.run()
    
if __name__=='__main__':
    pass
    