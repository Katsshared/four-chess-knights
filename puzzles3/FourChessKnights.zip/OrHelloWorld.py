'''
Created on 08.07.2026

@author: cat

https://docs.streamlit.io/develop/api-reference/caching-and-state/st.session_state

'''
import streamlit as st
import gettext

if 'sellang' not in st.session_state:
    st.write("No sellang found in session.")

localizator = gettext.translation('messages', localedir='locales', languages=[st.session_state.sellang])
localizator.install() 
_ = localizator.gettext 

st.title(_("Hello world"))

tab1, tab2, tab3, tab4, tab5 = st.tabs([_("Mission"), _("About us"), _("Careers"), _("Tasks"), _("Achievements")])
with tab1:
    st.header(_("Our Mission"))
    st.write(_("Our mission is to foster children's interest in playing chess."))
with tab2:
    st.header(_("About Us"))
    st.write(_("We are a children's chess club based at a center for social and integration cooperation."))
with tab3:
    st.header(_("Careers"))
    st.write(_("We are hiring! Apply today!"))
with tab4:
    st.header(_("Chess puzzles"))
    st.write(_("Mate in one move       Mate in two moves"))
with tab5:
    st.header(_("Our students' achievements"))
    st.write(_("Yakov (11 years old), Milena (8 years old), Lyuba (8 years old), Gosha (11 years old)"))
